<?php
session_start();
if($_SESSION['login']="yes")
{
  


  // Create database connection

 include 'db.php';



 
  
  	
  

$o_id=$_POST['oid'];
$c_id=$_POST['cid'];

     
      
        $sql = "INSERT INTO orde_r (C_ID,ORDER_ID)
VALUES ('$c_id','$o_id')";

 if(mysqli_query($con,$sql))
  {
      echo "ok";
       
       }
       else {
  echo "Error: " . $sql . "<br>" . $con->error;
}
     


 
}
  else
  {
    echo ('<script>location.href = "pages-404.html";</script>');
  }
  
  
  // $result = mysqli_query($db, "SELECT * FROM images");
?>