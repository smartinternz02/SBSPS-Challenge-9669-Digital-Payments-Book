<?php
$con=mysqli_connect('localhost','root','','ecomm');
if(!$con)
{
	die('error'.mysqli_connect_error());
}
?>