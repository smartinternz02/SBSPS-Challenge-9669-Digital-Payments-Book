<?php
require_once("dbf.php");
$db_handle = new DBController();
if(!empty($_POST["keyword"])) {
$query ="SELECT * FROM customer WHERE NAME like '" . $_POST["keyword"] . "%' ORDER BY NAME LIMIT 0,6";
$result = $db_handle->runQuery($query);
if(!empty($result)) {
?>
<ul id="pandal-list">
<?php
foreach($result as $country) {
?>
<li onClick="selectCountry('<?php echo $country["NAME"]; ?>');"><?php echo $country["NAME"]; ?></li>
<?php } ?>
</ul>
<?php } } ?>
